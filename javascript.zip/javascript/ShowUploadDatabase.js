var select = document.getElementsByTagName('select')[0];
// alert(select.value);

// select 值改变事件
select.onchange = function(){
    // alert(select.value);
    window.location.href = ("http://localhost:8080/ShowUploadDatabase?type=" + select.value);
};

// 载入文件时判断类型
function checkType(){
    var index = (String)(window.location).indexOf("?type=");
    if(index == -1){        // 全部
        return;
    }
    var type = (String)(window.location).substring(index + 6);
    type = type.trim();
    select.value = type;
}

checkType();

// 表格固定大小
var table = document.getElementsByTagName('table')[0];
table.style.width = '950px';

// 下拉菜单固定
var selectType = document.getElementById('selectType');
var showFile = document.getElementById('showFile');
selectType.style.position = 'fixed';
selectType.style.display = 'block';
selectType.style.height = '100px';
selectType.style.width = '100%';
selectType.style.zIndex = '2';
showFile.style.display = 'block';
showFile.style.position = 'absolute';
showFile.style.marginTop = '40px';

// 设置body 颜色
// document.getElementsByTagName('body')[0].bgColor = 'rgb(228, 228, 228)';     // 草，太绿了
document.getElementsByTagName('body')[0].style.backgroundColor = 'rgb(228, 228, 228)';