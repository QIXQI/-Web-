use test;

create table if not exists `chat`(
    `cid` int(11) not null auto_increment,
    `uid` int(11) not null,
    `username` varchar(255) not null,
    `iconID` int(11) not null default '1',
    `typeID` int(11) not null default '1',      -- 用户发送信息的类型， 1为文字，2为文件
    `message` varchar(255) not null default '',
    `time` datetime not null,
    primary key(`cid`)
) ENGINE=InnoDB auto_increment=1 default charset=utf8;