/**
 * 聊天系统问题总结：
 * 1. 输入框为空时，输不进去
 * 2. 自己提交信息时，刷新页面不能到达底部
 * 3. 定时刷新太 low， 服务器如何推送
 * 4. 在不同页面之间加入键绑定
 */

// alert("hello");
var browser = document.getElementById('u158');
var upload = document.getElementById('u160');
var browserFile = document.getElementsByClassName('fileupload')[0];         // 浏览文件
var uploadFile = document.getElementsByClassName('fileupload')[1];          // 上传文件

// 实现文件上传的浏览功能
browser.onclick = function(e){
    // alert("卧槽");
    // browserFile.style.display = 'block';
    browserFile.click();
    // alert(browserFile.value);        // 应该使用 onchange()方法
    e.stopPropagation();        // 阻止冒泡
};

// 实现文件上传的提交功能
upload.onclick = function(e){
    // alert("why");
    // uploadFile.style.display = 'block';
    document.getElementById('upload').submit();
    e.stopPropagation();        // 阻止冒泡
};

browserFile.onchange = function(){
    // alert(browserFile.value);           // 浏览器安全问题，无法获取文件真实路径
    document.getElementById('u156_div').getElementsByTagName('span')[0].innerText = browserFile.value;
};

// 实现上传文件更改时显示路径问题

/* document.body.onclick = function(){
    alert("hello");
};*/





// 实现叶面3聊天系统
document.getElementById('chat').onsubmit = function(){
    var message = document.getElementById('u301_input').value;
    if(message.trim() == ''){
        // alert('提交内容为空');
        return false;
    }
    
    // showchat 提交时只刷新不转换页面
    $("#chat").ajaxSubmit(function(){
        // 表单提交成功后的处理，message 为提交成功页面返回内容
        // alert(message);
        // alert('提交成功');

        // 提交成功刷新 showchat
        document.getElementById('chatIframe').contentWindow.location.reload(true);       // 提交时不会跳转到末尾
        // document.getElementById('chatIframe').src = 'http://localhost:8080/ShowChat#tfoot';      // 不刷新
        // $('#chatIframe').attr('src', $('#chatIframe').attr('src'));      // 哥哥也不跳转啊
    });
    return false;           // 防止提交两次
};



// 5s刷新 showchat 框架


// 页面4：根据用户名查找sql 记录
var searchInput = document.getElementById('u380_input');
var search = document.getElementById('u381');
var searchIframe = document.getElementById('searchIframe');

// 搜索事件
search.onclick = function(){
    var username = searchInput.value.trim();
    // alert(encodeURI(username));
    if(username == 'Username'){
        username = '';
    }
    // document.getElementById('searchIframe').contentWindow.location.reload(true);
    document.getElementById('searchIframe').src = 'http://localhost:8080/ShowFile?username=' + username;
};




// 实现登录注册登出
var userlog = document.getElementById('u6_input');

userlog.onchange = function(){
    // alert(userlog.value);
    if(userlog.value == 'login'){
        window.location.href = './login.html';
    }
};